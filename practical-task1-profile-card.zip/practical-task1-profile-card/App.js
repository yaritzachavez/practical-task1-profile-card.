import { View, Text, Image, StyleSheet, Platform, useWindowDimensions } from 'react-native';

const BIO =
  'Building cross-platform apps with React Native. I love clean layouts, accessible design and sharing what I learn with the community.';

const STATS = [
  { label: 'Projects', value: '24' },
  { label: 'Followers', value: '1.2k' },
  { label: 'Following', value: '180' },
];

const SKILLS = ['React Native', 'JavaScript', 'UI Design', 'Git', 'Flexbox'];

const COLORS = {
  background: '#EEF1F6',
  card: '#FFFFFF',
  text: '#1D2533',
  muted: '#788392',
  primary: '#5067CB',
  primaryLight: '#EDF0FF',
  border: '#E3E7EF',
  online: '#38BE77',
  shadow: '#000000',
};

function StatItem({ label, value, withDivider }) {
  return (
    <View style={[styles.stat, withDivider && styles.statDivider]}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function Tag({ label }) {
  return (
    <View style={styles.tag}>
      <Text style={styles.tagText}>{label}</Text>
    </View>
  );
}

export default function App() {
  const { width } = useWindowDimensions();

  return (
    <View style={styles.screen}>
      <View style={[styles.card, width > 600 && styles.wideCard]}>
        <Image source={require('./assets/banner.png')} style={styles.banner} resizeMode="cover" />

        <View style={styles.content}>
          <View style={styles.header}>
            <View style={styles.avatarContainer}>
              <Image source={require('./assets/avatar.png')} style={styles.avatar} resizeMode="cover" />
              <View style={styles.onlineBadge} />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.name}>Alex Rivera</Text>
              <Text style={styles.role}>Mobile Developer</Text>
              <Text style={styles.location}>Lisbon, Portugal</Text>
            </View>
          </View>

          <Text style={styles.bio} numberOfLines={3}>{BIO}</Text>

          <View style={styles.statsRow}>
            {STATS.map((stat, index) => (
              <StatItem key={stat.label} label={stat.label} value={stat.value} withDivider={index > 0} />
            ))}
          </View>

          <Text style={styles.sectionTitle}>Skills</Text>
          <View style={styles.tags}>
            {SKILLS.map((skill) => <Tag key={skill} label={skill} />)}
          </View>

          <View style={styles.actions}>
            <View style={[styles.button, styles.followButton]}>
              <Text style={styles.followText}>Follow</Text>
            </View>
            <View style={[styles.button, styles.messageButton]}>
              <Text style={styles.messageText}>Message</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: COLORS.background,
  },
  card: {
    width: '100%',
    backgroundColor: COLORS.card,
    borderRadius: 20,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: COLORS.shadow,
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.12,
        shadowRadius: 18,
      },
      android: { elevation: 7 },
      default: {},
    }),
  },
  wideCard: { maxWidth: 420 },
  banner: { width: '100%', height: 120 },
  content: { padding: 20, paddingTop: 0 },
  header: { flexDirection: 'row', alignItems: 'flex-start' },
  avatarContainer: { width: 96, height: 96, marginTop: -35 },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 48,
    borderWidth: 4,
    borderColor: COLORS.card,
  },
  onlineBadge: {
    position: 'absolute',
    right: 3,
    bottom: 4,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: COLORS.online,
    borderWidth: 3,
    borderColor: COLORS.card,
  },
  headerText: { flex: 1, marginLeft: 12, marginTop: 13 },
  name: { fontSize: 22, fontWeight: '700', color: COLORS.text },
  role: { fontSize: 14, fontWeight: '600', color: COLORS.primary, marginTop: 3 },
  location: { fontSize: 12, color: COLORS.muted, marginTop: 4 },
  bio: { color: COLORS.text, fontSize: 14, lineHeight: 21, marginTop: 18 },
  statsRow: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: COLORS.border,
    paddingVertical: 16,
    marginTop: 20,
  },
  stat: { flex: 1, alignItems: 'center' },
  statDivider: { borderLeftWidth: 1, borderLeftColor: COLORS.border },
  statValue: { fontSize: 18, fontWeight: '700', color: COLORS.text },
  statLabel: { fontSize: 12, color: COLORS.muted, marginTop: 4 },
  sectionTitle: {
    textTransform: 'uppercase',
    letterSpacing: 1.3,
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.muted,
    marginTop: 20,
    marginBottom: 12,
  },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tag: {
    backgroundColor: COLORS.primaryLight,
    borderRadius: 50,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  tagText: { color: COLORS.primary, fontSize: 12, fontWeight: '600' },
  actions: { flexDirection: 'row', gap: 12, marginTop: 24 },
  button: { flex: 1, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  followButton: { backgroundColor: COLORS.primary },
  messageButton: { borderWidth: 1, borderColor: COLORS.primary },
  followText: { color: COLORS.card, fontWeight: '700' },
  messageText: { color: COLORS.primary, fontWeight: '700' },
});
