# Checkpoint Answers — Practical Task 1

1. **What is the default value of `flexDirection` in React Native? How is it different from CSS on the web?**
   In React Native, the default is `column`, so elements stack vertically. On the web, Flexbox defaults to `row`, placing elements horizontally.

2. **What is the difference between `justifyContent` and `alignItems`?**
   `justifyContent` arranges children along the main axis, while `alignItems` arranges them along the cross axis. In a row, this means horizontal and vertical alignment respectively.

3. **What does `flex: 1` do inside a row? And on the outermost `View` of a screen?**
   Inside a row, `flex: 1` lets an element take a share of the available horizontal space. On the outer screen container, it makes the View expand to occupy the available screen area.

4. **What is the difference between `resizeMode="cover"` and `resizeMode="contain"`?**
   `cover` fills the image area while preserving proportions, so part of the picture may be cropped. `contain` shows the full image but can leave empty space around it.

5. **Why do we use `StyleSheet.create` instead of plain objects inside the JSX?**
   It keeps styles organized and easier to reuse throughout the app. It also makes the layout code easier to read and helps avoid creating new inline style objects on each render.

6. **Why does a shadow written with `shadowColor` not appear on Android?**
   The iOS shadow properties such as `shadowOffset`, `shadowOpacity`, and `shadowRadius` do not work the same way on Android. Using `elevation` creates the usual Android shadow; `Platform.select` lets us set up both platforms.
