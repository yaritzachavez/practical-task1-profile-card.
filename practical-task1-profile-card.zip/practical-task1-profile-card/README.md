# Practical Task 1 — Basics. Components

React Native profile card built with Expo using `View`, `Text`, `Image`, Flexbox and `StyleSheet`.

## Run locally

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go or open the app in an emulator.

## Features

- Local cover and profile photos
- Overlapping circular avatar with online indicator
- Responsive header and three-column stats
- Wrapped skill badges and two action layouts
- Platform-specific card shadow
- Reusable `StatItem` and `Tag` components

See [ANSWERS.md](ANSWERS.md) for the checkpoint answers and [expected-result.png](expected-result.png) for the provided reference image.
